<html lang="en">
<head>
  <title>Academics</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="main.css">
  <link rel="stylesheet" href="bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
</head>
<body>



<div class="container-fluid">
<?php include('header.php');?>
</div>
<?php include('navigation.php');?>
<p> Central Oregon Community College <br>
    Bend, Oregon <br>
    GPA: 3.4 out of 4 <br>
    Attended 2016-2018 <br>
    Graduated with an Associates of Science Transfer Degree <br>
    Hybrid course work- both in person and online <br>
</p><br>
   <p>Linfield College <br>
   <p> McMinnville, Oregon <br>
    GPA: 3.4 out of 4 <br>
    Attended 2019-2020 <br>
    Graduated with a Bachelors in Business Information Systems <br>
    Course work completely online <br>
</p>
<?php include('Footer.php');?>
    </body>