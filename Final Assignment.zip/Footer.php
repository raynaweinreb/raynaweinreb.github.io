<head>
  <title>Footer</title>
<p>Wilsonville, Oregon</p>


<style>
p {text-align: center;
  font-family: "Lucida Console", Monaco, monospace;
    color: crimson}
  
    </style>