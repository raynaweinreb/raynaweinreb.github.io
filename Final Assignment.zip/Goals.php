<!DOCTYPE html>
<html lang="en">
<head>
  <title>Goals</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="main.css">
  <link rel="stylesheet" href="bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
</head>
<body>

<div class="container-fluid">
<?php include('header.php');?>
</div>
<?php include('navigation.php');?>
<p>
I have found a passion for project management. I enjoy the organization and planning part of it. My goal is to become a project manager for a software development company. I have the technical skills like being able to translate requirements to developers. <br>
To acheive my goals, I would like to find a job starting in IT. In this postition I will grow my knowledge of information systems. <br>
After a few years, I would like to find a business analyst position where I can start doing project management tasks and build my skills. In this position I would like to learn the ins and outs of business analysis and be able to use them in my project management career. <br>
Finally, after years of broadening my kills, I would like to be able to find a job in project managament. I will use all of the skills I have learned in previous jobs to lead projects all the way through. 

</p>
<?php include('Footer.php');?>
</body>
</html>