<!DOCTYPE html>
<html lang="en">
<head>
  <title>Hobbies</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="main.css">
  <link rel="stylesheet" href="bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
</head>
<body>

<div class="container-fluid">
<?php include('header.php');?>
</div>
<?php include('navigation.php');?>
<p> Lately, my hobbies have inlcluded hiking with my two dogs.
    </p><br>
    <img src="IMG_3400.jpeg" alt="Picture of Rayna and Gunner"><br>
    <p>Paddle boarding as much as possible</p><br>
    <img src="IMG_3398.jpeg" alt="Picture of Rayna/Gunner"><br>
    <p> When i'm not home you can always find me at the beach</p><br>
    <img src="IMG_3399.jpeg" alt="Picture of Rayna/Gunner"><br>
    
<?php include('Footer.php');?>
</body>
</html>