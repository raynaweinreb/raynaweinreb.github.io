<head>
  <title>Header</title>
<h1>Rayna Weinreb</h1>
<p>Business Information Systems Major-
    Linfield College Graduate</p>

<img  src="IMG_3418.JPG" class="header" style="width: 60%;
    height: 200px;
    display: block;
  margin-left: auto;
  margin-right: auto" alt="Picture of Rayna">


<style>
 h1 {text-align: center;
     font-family: "Lucida Console", Monaco, monospace;
     color:black
}
p {text-align: center;
  font-family: "Lucida Console", Monaco, monospace;
    color: crimson}

    

</style>  
