<!DOCTYPE html>
<html lang="en">
<head>
  <title>Rayna Weinreb</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="main.css">
  <link rel="stylesheet" href="bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
</head>
<body>

<div class="container-fluid">
<?php include('header.php');?>
</div>
<?php include('navigation.php');?>
<p> Hello, and welcome to my website. By clicking through my website you will gain a better understanding of my life and my education. I have used this site to express my goals and my hobbies as well as show off my educational acheivements. Please feel free to contact me with any questions or concerns. Thank you for taking a look at my site!
</p>
<img src="FullSizeRender.jpeg" alt="Picture of Rayna">

<?php include('Footer.php');?>
</body>
</html>