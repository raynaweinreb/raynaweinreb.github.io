

<?php
echo
    '<ul>
    <li><a href="index.php">Home</a></li>
    <li><a href="Academics.php">Academics</a></li>
    <li><a href="Hobbies.php">Hobbies</a></li> 
    <li><a href="Goals.php">Goals</a></li>
    <li><a href="transcripts.php">Transcripts</a></li>
    <li><a href="Contact.php">Contact Me</a></li>
</ul>';
?>
